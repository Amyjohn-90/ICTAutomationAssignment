import com.aventstack.extentreports.Status;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class Listener extends Driver implements ITestListener {

       @Override
    public void onTestSuccess(ITestResult result) {
           extentTest.log(Status.PASS, result.getName());
           //extentTest.addScreenCaptureFromPath(Driver.takeScreenshot());
        //System.out.println("Success of test cases and its details are : "+result.getName());
    }

    @Override
    public void onTestFailure(ITestResult result) {
        extentTest.log(Status.FAIL, result.getName());
        //System.out.println("Failure of test cases and its details are : "+result.getName());
    }
}
