import org.testng.annotations.DataProvider;

public class TestData {
    @DataProvider(name = "movie search positive")
    public Object[] getCorrectMovie(){
        String[][] movieName = {
                {"Fantasy Island"}
        };
        return movieName;
    }
    @DataProvider(name = "movie search negative")
    public Object[] getWrongMovie(){
        String[][] movieName = {
                {"qq"}
        };
        return movieName;
    }
    @DataProvider(name = "city name")
    public Object[] getCityName() {
        String[][] cityName = {
                {"Goa"}
        };
        return cityName;
    }
    @DataProvider(name="cast and crew")
    public Object[][]getCastandCrew() {
        String[][] castCrewName = {
                {"Tom Holland","Mychael Danna"}
                };
        return castCrewName;
    }
    @DataProvider(name="neg cast and crew")
    public Object[][]getNegCastandCrew() {
        String[][] negcastCrewName = {
                {"Tom Cruise","Michael Jackson"}
        };
        return negcastCrewName;
    }
    @DataProvider(name = "ICICI offer message")
    public Object[] getICICIoffer(){
        String[][] offer = {
                {"ICICI Bank Cr"}
        };
        return offer;
    }
    @DataProvider(name = "Kotak offer message")
    public Object[] getKotakoffer(){
        String[][] offer = {
                {"Kotak Mahindra Offe"}
        };
        return offer;
    }

}
