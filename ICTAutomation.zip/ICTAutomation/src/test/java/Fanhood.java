import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class Fanhood {
    private WebDriver driver;
    public Fanhood(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//*[@class='header__logo-image']")
    WebElement headerLogo;
    @FindBy(xpath = "//*[@class='container']/ul/li[2]/a")
    WebElement products;
    @FindBy(xpath = "//*[@class='mega-menu__link link'][@href='/collections/lunch-bags']")
    WebElement lunchBags;
    @FindBy(xpath = "//*[@class='mega-menu__link link'][@href='/collections/planner']")
    WebElement planner;
    @FindBy(xpath = "//*[@id='ajaxSort']")
    WebElement sort;
    @FindBy(xpath = "//*[@value='title-descending']")
    WebElement sortDescending;
    @FindBy(xpath = " //*[@class='filter-content']/li[@data-tag='0-500']")
    WebElement filterByPrice;
    @FindBy(xpath = " //*[@class='collection__showing-count hidden-lap mm-product-header']")
    WebElement dynamicContent;

    public void verifyFanhoodPage(){
        BookMyShowHome Obj = new BookMyShowHome(driver);
        Obj.clickFanhood();
        Assert.assertEquals("Fanhood",headerLogo.getAttribute("alt"));
        String url = driver.getCurrentUrl();
        Assert.assertTrue(url.contains("fanhood"));
    }

    public void validateSortedProduct(){
        verifyFanhoodPage();
        products.click();
        lunchBags.click();
        sort.click();
        sortDescending.click();

    }
    public void validateFilterByPrice(){
        verifyFanhoodPage();
            products.click();
            planner.click();
            List<WebElement> items = driver.findElements(By.xpath("//*[@class='product-item product-item--vertical  1/3--tablet-and-up 1/4--desk']"));
            System.out.println("Products Displayed = " + items.size());
            filterByPrice.click();
            System.out.println(dynamicContent.getText());
    }
}
