import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.IOException;
import java.sql.SQLOutput;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class BookMyShowHome {

    private WebDriver driver;

    @FindBy(xpath = "//*[@id='preSignIn']")
    WebElement toAssert;
    @FindBy(xpath = "//*[@id='inp_RegionSearch_top']")
    WebElement enterCity;
    @FindBy(xpath = "//*[@id=\"spnSelectedRegion\"]")
    WebElement cityLoaded;
    @FindBy(xpath = "//*[@class='tt-highlight']")
    WebElement autoOptions;
    @FindBy(xpath = "//*[@id='wzrk-cancel']")
    WebElement dismissAlert;
    @FindBy(xpath = "//*[@id=\"showcase-primary\"]/div[2]/span")
    WebElement overlayDismiss;
    @FindBy(xpath = "//*[@id='input-search-box']")
    WebElement movieSearch;
    @FindBy(xpath = "//*[@id=\"quickbook-wrapper\"]/div[1]/div[1]/span[1]/div/div/div[2]/span[1]/img")
    WebElement movieSelect;
    @FindBy(xpath = "//*[@id='eventTitle']")
    WebElement movieFound;
    @FindBy(xpath = "//*[@id=\"quickbook-movies\"]/div[2]/div/div/div[2]/span")
    WebElement movieNotFound;
    @FindBy(xpath = "//*[@id=\"navbar\"]/div[3]/div/div[2]/ul/li[1]/a")
    WebElement listYourShow;
    @FindBy(xpath = "//*[@id=\"navbar\"]/div[3]/div/div[2]/ul/li[3]/a")
    WebElement offers;
    @FindBy(xpath = "//*[@class='col app']")
    WebElement footerApp;
    @FindBy(xpath = "//*[@class='col news']")
    WebElement footerNews;
    @FindBy(xpath = "//*[@class='col help']")
    WebElement footerExclusives;
    @FindBy(xpath = "//*[@class='col exclusives']")
    WebElement footerHelp;
    @FindBy(xpath = "//*[@class ='__brand-Langdropdown']")
    WebElement selectLang;
    @FindBy(xpath =" //*[@data-name]")
    WebElement getLangList;
    @FindBy(xpath = "//*[@class='primary-nav']//li[7]/a")
    WebElement clickFanhood;

    public BookMyShowHome(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void yourcity(){
        enterCity.sendKeys("Kochi");
        String optionsToSelect = autoOptions.getText();
        if (optionsToSelect.equals("Kochi")) {
            autoOptions.click();
        }
        driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
        dismissAlert.click();
    }

    public void selectCityGoa(String city) throws IOException, InterruptedException {
        enterCity.sendKeys(city);
        String optionsToSelect = autoOptions.getText();
        if (optionsToSelect.equals(city)) {
            autoOptions.click();
            }
        driver.manage().timeouts().implicitlyWait(30000, TimeUnit.MILLISECONDS);
        overlayDismiss.click();
        dismissAlert.click();
        driver.manage().timeouts().implicitlyWait(30000, TimeUnit.MILLISECONDS);
        Assert.assertEquals(city,cityLoaded.getText());
    }

    public void positiveMovieSearch(String movie) throws IOException {
    yourcity();
        driver.navigate().to("https://in.bookmyshow.com/kochi#!quickbook");
            movieSearch.sendKeys(movie);
            movieSelect.click();
            String actualMovie = movieFound.getAttribute("title");
            Assert.assertEquals(movie,actualMovie);

    }

    public void negativeMovieSearch(String movie) {
     yourcity();
        driver.navigate().to("https://in.bookmyshow.com/kochi#!quickbook");
        movieSearch.sendKeys(movie);
        Assert.assertEquals("Oops!", movieNotFound.getText());
    }

     public void clickListYourShow(){
        listYourShow.click();
    }
    public void clickOffers(){
        offers.click();
    }

    public Boolean footerTextValidation(){
        yourcity();
        driver.manage().timeouts().implicitlyWait(60000, TimeUnit.MILLISECONDS);
        dismissAlert.click();
        footerApp.isDisplayed();
        System.out.println("footer app " +footerApp.getText());
        footerNews.isDisplayed();
        System.out.println("News "+footerNews.getText());
        footerExclusives.isDisplayed();
        System.out.println("Exclusives "+footerExclusives.getText());
        footerHelp.isDisplayed();
        System.out.println("Help "+footerHelp.getText());
        return true;
    }

    public void  printLanguageOptions(){
        yourcity();
        selectLang.click();
        List<WebElement> languages = driver.findElements(By.xpath(" //*[@data-name]"));
        System.out.println("Languages present = "+languages.size());
        for (WebElement webElement : languages) {
            String name = webElement.getText();
            System.out.println(name);
        }

    }

    public void clickFanhood(){
        yourcity();
        clickFanhood.click();
    }

}