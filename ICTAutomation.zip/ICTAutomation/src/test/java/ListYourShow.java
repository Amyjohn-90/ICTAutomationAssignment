import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class ListYourShow {
    private WebDriver driver;
    public ListYourShow(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
@FindBy(xpath = "//div[@open-modal='Streaming']")
    WebElement onlStreaming;
    @FindBy(xpath="//div[@open-modal='Performances']")
    WebElement performances;
    @FindBy(xpath = "//div[@open-modal='Experiences']")
    WebElement experiences;
    @FindBy(xpath = "//div[@open-modal='Expositions']")
    WebElement expositions;
    @FindBy(xpath = "//div[@open-modal='Parties']")
    WebElement parties;
    @FindBy(xpath = "//div[@open-modal='Sports']")
    WebElement sports;
    @FindBy(xpath = "//div[@open-modal='Conferences']")
    WebElement conferences;
    @FindBy(xpath ="//*[@open-modal='Sales']")
    WebElement sales;
    @FindBy(xpath = "//*[@open-modal='Pricing']")
    WebElement pricing;
    @FindBy(xpath = "//*[@open-modal='Food']")
    WebElement food;
    @FindBy(xpath = "//*[@open-modal='Onground']")
    WebElement onground;
    @FindBy(xpath = "//*[@open-modal='Reports']")
    WebElement reports;
    @FindBy(xpath = "//*[@open-modal='Pos']")
    WebElement pos;
    @FindBy(xpath = "//*[@close-modal = 'Reports']")
    WebElement openReports;


    public void whatCanYouHost(){
        BookMyShowHome Obj = new BookMyShowHome(driver);
        Obj.yourcity();
        Obj.clickListYourShow();
        Assert.assertTrue(onlStreaming.isDisplayed());
        Assert.assertTrue(performances.isDisplayed());
        Assert.assertTrue(experiences.isDisplayed());
        Assert.assertTrue(expositions.isDisplayed());
        Assert.assertTrue(parties.isDisplayed());
        Assert.assertTrue(sports.isDisplayed());
        Assert.assertTrue(conferences.isDisplayed());
        }

        public void servicesWeOffer(){
            BookMyShowHome Obj = new BookMyShowHome(driver);
            Obj.yourcity();
            Obj.clickListYourShow();
            Assert.assertTrue(sales.isDisplayed());
            Assert.assertTrue(pricing.isDisplayed());
            Assert.assertTrue(food.isDisplayed());
            Assert.assertTrue(onground.isDisplayed());
            Assert.assertTrue(reports.isDisplayed());
            Assert.assertTrue(pos.isDisplayed());
        }

        public void reportsAndBusiness(){
            BookMyShowHome Obj = new BookMyShowHome(driver);
            Obj.yourcity();
            Obj.clickListYourShow();
            reports.click();
            Assert.assertTrue(openReports.isDisplayed());
        }



}
