import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class MovieDetailsPage {
    private WebDriver driver;

    @FindBy(xpath = "//*[@content='Tom Holland']")
    WebElement castWeb;

    @FindBy(xpath ="//*[@content='Mychael Danna']")
    WebElement crewWeb;

    public MovieDetailsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void positiveCastAndCrew(String cast, String crew) throws IOException {
        BookMyShowHome Obj = new BookMyShowHome(driver);
        Obj.positiveMovieSearch("Onward");
        String actualCast = castWeb.getAttribute("content");
        System.out.println("Actor "+actualCast);
        String actualCrew = crewWeb.getAttribute("content");
        System.out.println("Musician "+actualCrew);
        int actor = actualCast.compareTo(cast);
        int musician = actualCrew.compareTo(crew);
        if(actor==0 && musician==0){
            System.out.println("test pass");
            Assert.assertTrue(true);
        }
    }

    public void negativeCastAndCrew(String cast, String crew) throws IOException {
        BookMyShowHome Obj = new BookMyShowHome(driver);
        Obj.positiveMovieSearch("Onward");
        String actualCast = castWeb.getAttribute("content");
        System.out.println("Actor "+actualCast);
        String actualCrew = crewWeb.getAttribute("content");
        System.out.println("Musician "+actualCrew);
        int actor = actualCast.compareTo(cast);
        int musician = actualCrew.compareTo(crew);
        if(actor != 0 && musician!=0){
            System.out.println("test pass");
            Assert.assertTrue(true);
        }
    }

}
