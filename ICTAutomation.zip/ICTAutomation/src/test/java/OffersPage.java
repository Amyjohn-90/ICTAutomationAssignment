import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.concurrent.TimeUnit;

public class OffersPage {
    private WebDriver driver;
    public OffersPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//*[@data-id='rewards']")
    WebElement rewards;
    @FindBy(xpath = "//*[@data-id='offers-SimplyCLICK-SBI-Card-Rewards-Offer']")
    WebElement sbiRewards;
    @FindBy(xpath = "//*[@class = '__seach-input typeahead tt-input']")
    WebElement searchOffer;
    @FindBy(xpath = "//*[@class='tt-highlight']")
    WebElement selectICICI;
    @FindBy(xpath = "//*[@id='ICICICC520']")
    WebElement showICICI;
    @FindBy(xpath = "//*[@class='tt-no-results']")
    WebElement noKotak;

    public void viewSBIcardOffers(){
        BookMyShowHome Obj = new BookMyShowHome(driver);
        Obj.yourcity();
        Obj.clickOffers();
        rewards.click();
        Assert.assertTrue(sbiRewards.isDisplayed());
    }

    public void viewICICIcardOffers(String offerMessage){
        BookMyShowHome Obj = new BookMyShowHome(driver);
        Obj.yourcity();
        Obj.clickOffers();
        searchOffer.sendKeys(offerMessage);
        selectICICI.click();
        driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
        Assert.assertTrue(showICICI.isDisplayed());
    }

    public void viewKotakOffers(String offerMessage){
        BookMyShowHome Obj = new BookMyShowHome(driver);
        Obj.yourcity();
        Obj.clickOffers();
        searchOffer.sendKeys(offerMessage);
        driver.manage().timeouts().implicitlyWait(20000, TimeUnit.MILLISECONDS);
        Assert.assertTrue(noKotak.isDisplayed());
    }

}
