import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
@Listeners
public class Execution extends Driver {

    @Test(priority = 1, dataProviderClass = TestData.class, dataProvider = "city name")
    public void testcase_SelectCityGoa(String cityName) throws IOException, InterruptedException {
        extentTest = reports.createTest("Select city Goa");
        WebDriver driver = Driver.openBrowser();
        BookMyShowHome homePage = new BookMyShowHome(driver);
        driver.manage().timeouts().implicitlyWait(60000, TimeUnit.MILLISECONDS);
        homePage.selectCityGoa(cityName);
        //extentTest.log(Status.PASS, "City selected");
        extentTest.addScreenCaptureFromPath(Driver.takeScreenshot());
    }

    @Test(priority = 2, dataProviderClass = TestData.class, dataProvider = "movie search positive")
    public void testcase_positiveMovieSearch(String movieName) throws IOException, InterruptedException {
       extentTest = reports.createTest("Positive movie search");
       WebDriver driver = Driver.openBrowser();
        BookMyShowHome homePage = new BookMyShowHome(driver);
        driver.manage().timeouts().implicitlyWait(60000, TimeUnit.MILLISECONDS);
        homePage.positiveMovieSearch(movieName);
        //extentTest.log(Status.PASS, "Movie search positive");
        extentTest.addScreenCaptureFromPath(Driver.takeScreenshot());
    }

    @Test(priority = 3, dataProviderClass = TestData.class, dataProvider = "movie search negative")
    public void testcase_negativeMovieSearch(String movieName) throws IOException, InterruptedException {
        extentTest = reports.createTest("Negative movie search");
        WebDriver driver = Driver.openBrowser();
        BookMyShowHome homePage = new BookMyShowHome(driver);
        driver.manage().timeouts().implicitlyWait(60000, TimeUnit.MILLISECONDS);
        homePage.negativeMovieSearch(movieName);
        //extentTest.log(Status.PASS, "Negative movie search");
        extentTest.addScreenCaptureFromPath(Driver.takeScreenshot());
    }

    @Test(priority = 4, dataProviderClass = TestData.class, dataProvider = "cast and crew")
    public void testcase_positiveCastAndCrew(String castName, String crewName) throws IOException {
        extentTest = reports.createTest("Positive cast and crew");
        WebDriver driver = Driver.openBrowser();
        MovieDetailsPage details = new MovieDetailsPage(driver);
        driver.manage().timeouts().implicitlyWait(60000, TimeUnit.MILLISECONDS);
        details.positiveCastAndCrew(castName,crewName);
        //extentTest.log(Status.PASS, "Positive cast and crew");
        extentTest.addScreenCaptureFromPath(Driver.takeScreenshot());
    }

    @Test(priority = 5, dataProviderClass = TestData.class, dataProvider = "neg cast and crew")
    public void testcase_neagtiveCastAndCrew(String castName, String crewName) throws IOException {
        extentTest = reports.createTest("Negative cast and crew");
        WebDriver driver = Driver.openBrowser();
        MovieDetailsPage details = new MovieDetailsPage(driver);
        driver.manage().timeouts().implicitlyWait(60000, TimeUnit.MILLISECONDS);
        details.positiveCastAndCrew(castName,crewName);
        //extentTest.log(Status.PASS, "Negative cast and crew");
        extentTest.addScreenCaptureFromPath(Driver.takeScreenshot());
    }

    @Test(priority = 6)
    public void testcase_whatyoucanhost() throws IOException {
        extentTest = reports.createTest("What you can host");
        WebDriver driver = Driver.openBrowser();
        ListYourShow host = new ListYourShow(driver);
        driver.manage().timeouts().implicitlyWait(60000, TimeUnit.MILLISECONDS);
        host.whatCanYouHost();
        //extentTest.log(Status.PASS, "What you can host");
        extentTest.addScreenCaptureFromPath(Driver.takeScreenshot());
    }

    @Test(priority = 7)
    public void testcase_servicesWeOffer() throws IOException {
        extentTest = reports.createTest("Services we offer");
        WebDriver driver = Driver.openBrowser();
        ListYourShow host = new ListYourShow(driver);
        driver.manage().timeouts().implicitlyWait(60000, TimeUnit.MILLISECONDS);
        host.servicesWeOffer();
        //extentTest.log(Status.PASS, "Services we offer");
        extentTest.addScreenCaptureFromPath(Driver.takeScreenshot());
    }

    @Test(priority = 8)
    public void testcase_ReportsandBusiness() throws IOException {
        extentTest = reports.createTest("Reports and business");
        WebDriver driver = Driver.openBrowser();
        ListYourShow host = new ListYourShow(driver);
        driver.manage().timeouts().implicitlyWait(60000, TimeUnit.MILLISECONDS);
        host.reportsAndBusiness();
        //extentTest.log(Status.PASS, "Reports and business");
        extentTest.addScreenCaptureFromPath(Driver.takeScreenshot());
    }

    @Test(priority = 9)
    public void testcase_viewSBIcardOffers() throws IOException {
        extentTest = reports.createTest("SBI card offers");
        WebDriver driver = Driver.openBrowser();
        OffersPage offers = new OffersPage(driver);
        driver.manage().timeouts().implicitlyWait(60000, TimeUnit.MILLISECONDS);
        offers.viewSBIcardOffers();
        //extentTest.log(Status.PASS, "SBI card offers");
        extentTest.addScreenCaptureFromPath(Driver.takeScreenshot());
    }

    @Test(priority = 10, dataProviderClass = TestData.class, dataProvider = "ICICI offer message")
    public void testcase_viewICICIcardOffers(String offer) throws IOException {
       extentTest = reports.createTest("ICICI card offers");
        WebDriver driver = Driver.openBrowser();
        OffersPage offers = new OffersPage(driver);
        driver.manage().timeouts().implicitlyWait(60000, TimeUnit.MILLISECONDS);
        offers.viewICICIcardOffers(offer);
        //extentTest.log(Status.PASS, "ICICI card offers");
        extentTest.addScreenCaptureFromPath(Driver.takeScreenshot());
    }

    @Test(priority = 11, dataProviderClass = TestData.class, dataProvider = "Kotak offer message")
    public void testcase_viewKotakMahindraOffers(String offer) throws IOException {
        extentTest = reports.createTest("Kotak Mahindra offer");
        WebDriver driver = Driver.openBrowser();
        OffersPage offers = new OffersPage(driver);
        driver.manage().timeouts().implicitlyWait(60000, TimeUnit.MILLISECONDS);
        offers.viewKotakOffers(offer);
        //extentTest.log(Status.PASS, "Kotak Mahindra offer");
        extentTest.addScreenCaptureFromPath(Driver.takeScreenshot());
    }

    @Test(priority = 12)
    public void testcase_footerTextValidation() throws IOException {
        extentTest = reports.createTest("Footer text validation");
        WebDriver driver = Driver.openBrowser();
        BookMyShowHome Obj = new BookMyShowHome(driver);
        driver.manage().timeouts().implicitlyWait(60000, TimeUnit.MILLISECONDS);
        Assert.assertTrue(Obj.footerTextValidation());
        //extentTest.log(Status.PASS, "Footer text validation");
        extentTest.addScreenCaptureFromPath(Driver.takeScreenshot());
    }

    @Test(priority = 13)
    public void testcase_printLanguageOptions() throws IOException {
        extentTest = reports.createTest("Print languages");
        WebDriver driver = Driver.openBrowser();
        BookMyShowHome Obj = new BookMyShowHome(driver);
        driver.manage().timeouts().implicitlyWait(60000, TimeUnit.MILLISECONDS);
        Obj.printLanguageOptions();
        //extentTest.log(Status.PASS, "Print languages");
        extentTest.addScreenCaptureFromPath(Driver.takeScreenshot());
       }

    @Test(priority = 14)
    public void testcase_validateSortedProduct() throws IOException {
        extentTest = reports.createTest("Validate sorted Product");
        WebDriver driver = Driver.openBrowser();
        Fanhood Obj = new Fanhood(driver);
        driver.manage().timeouts().implicitlyWait(60000, TimeUnit.MILLISECONDS);
        Obj.validateSortedProduct();
        //extentTest.log(Status.PASS, "Validate sorted Product");
        extentTest.addScreenCaptureFromPath(Driver.takeScreenshot());
      }

    @Test(priority = 15)
    public void testcase_validateFilterByPrice() throws IOException {
        extentTest = reports.createTest("Validate filter by price");
        WebDriver driver = Driver.openBrowser();
        Fanhood Obj = new Fanhood(driver);
       driver.manage().timeouts().implicitlyWait(60000, TimeUnit.MILLISECONDS);
        Obj.validateFilterByPrice();
        //extentTest.log(Status.PASS, "Validate filter by price");
        extentTest.addScreenCaptureFromPath(Driver.takeScreenshot());
     }
}